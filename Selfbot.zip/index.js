const { Client, MessageEmbed } = require('discord.js-selfbot-v13');
const { joinVoiceChannel, VoiceConnectionStatus, entersState } = require('@discordjs/voice');
const fs = require('fs');

const client = new Client({ checkUpdate: false });
const PREFIX = '!';

let autoMessageInterval = null;
let autoReactBotIds = [];
let currentConnection = null;
let shopInterval = null;
let autoReactEnabled = false; 
let mentionAutoReplyMessage = null; 
let mentionAutoReplyEnabled = false; 
let dmAutoReplyEnabled = true; 
let selfModeEnabled = true; 

try {
    var words = fs.readFileSync('words.txt', 'utf-8').split('\n').filter(word => word.trim() !== '');
    var shopMessage = fs.readFileSync('shop.txt', 'utf-8').trim();
} catch (e) {
    console.error('Error reading words.txt or shop.txt:', e.message);
    var words = ['Error: words.txt not found or empty!']; 
    var shopMessage = 'Error: shop.txt not found or empty!';
}

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {

    if (message.author.id !== client.user.id) return;

    if (message.content.startsWith(`${PREFIX}self`)) {
        const args = message.content.split(' ');
        if (args.length < 2) return message.reply('Usage: `!self enable` or `!self disable`');
        const action = args[1].toLowerCase();

        if (action === 'enable') {
            selfModeEnabled = true;
            return message.reply('✅ Self-Bot mode **enabled**.');
        } else if (action === 'disable') {
            if (autoMessageInterval) clearInterval(autoMessageInterval);
            if (shopInterval) clearInterval(shopInterval);
            
            autoMessageInterval = null;
            shopInterval = null;
            
            selfModeEnabled = false;
            return message.reply('❌ Self-Bot mode **disabled**. All auto-commands and intervals are now stopped.');
        } else {
            return message.reply('Usage: `!self enable` or `!self disable`');
        }
    }

    if (!selfModeEnabled) return; 

    if (message.content.startsWith(`${PREFIX}spam`)) {
        const args = message.content.split(' ');
        
        if (args.length < 3) { 
            return message.reply('Usage: `!spam <message> <count>`');
        }
        const count = parseInt(args[args.length - 1]); 
        
        const spamMessage = args.slice(1, args.length - 1).join(' ');
        if (isNaN(count) || count <= 0) {
            return message.reply('❌ Invalid count. Please use a positive number.');
        }
        
        if (count > 20) {
            return message.reply('⚠️ Max spam count is **20** to avoid rate limiting.');
        }
        
        if (!spamMessage) {
            return message.reply('Usage: `!spam <message> <count>`');
        }
        try {
            await message.delete();
        } catch (e) {
            console.error('Failed to delete spam command message:', e);
        }
        for (let i = 0; i < count; i++) {
            await message.channel.send(spamMessage).catch(console.error);
        }
        
        return; 
    }

    if (message.content.startsWith(`${PREFIX}embed`)) {
        const usage = 'Usage: `!embed <title> | <Embed content> | <#COLOR> | <footer (optional)> | <image_URL (optional)>`';
        const content = message.content.substring(`${PREFIX}embed`.length).trim();
        const parts = content.split('|').map(p => p.trim());
        if (parts.length < 3 || !parts[0] || !parts[1] || !parts[2]) {
            return message.reply(`❌ Missing required parts. ${usage}`);
        }
        const title = parts[0];
        const description = parts[1];
        const colorInput = parts[2];
        const footer = parts[3] || null;
        const imageUrl = parts[4] || null;
        let embedColor = '#0099ff'; 
        if (colorInput && /^#[0-9A-F]{6}$/i.test(colorInput)) {
            embedColor = colorInput;
        }
        try {
            const embed = new MessageEmbed()
                .setTitle(title)
                .setDescription(description)
                .setColor(embedColor)
                .setAuthor({ 
                    name: message.author.tag, 
                    iconURL: message.author.displayAvatarURL({ dynamic: true }) 
                })
                .setTimestamp();
            if (footer) {
                embed.setFooter({ text: footer });
            }
            
            if (imageUrl) {
                 embed.setImage(imageUrl);
            }
            await message.channel.send({ embeds: [embed] });
            
            await message.delete(); 
        } catch (error) {
            console.error('Failed to send complex embed:', error);
            message.reply('❌ Failed to send embed. Check image URL or color format. Must be Hex (#RRGGBB).');
        }
        return; 
    }

    if (message.content.startsWith(`${PREFIX}status`)) {
        const args = message.content.split(' ').slice(1);
        
        if (args.length === 0) return message.reply('Usage: `!status <playing/streaming/reset> <message> [url (optional)]`');

        const type = args[0].toLowerCase();
        
        if (type === 'reset') {
            await client.user.setActivity(null);
            return message.reply('✅ User activity status has been reset.');
        }

        if (args.length < 2) return message.reply('Usage: `!status <playing/streaming> <message> [url (optional)]`');

        
        let activityUrl = null;
        let activityMessage;
        
        const lastArg = args[args.length - 1];
        if (lastArg.startsWith('http') || lastArg.startsWith('https')) {
            activityUrl = lastArg;
            activityMessage = args.slice(1, args.length - 1).join(' '); 
        } else {
            activityMessage = args.slice(1).join(' '); 
        }
        
        if (!activityMessage.trim()) return message.reply('❌ The activity message cannot be empty.');


        let activityType;
        let activityOptions = { name: activityMessage };
        
        if (type === 'playing' || type === 'listening' || type === 'watching' || type === 'competing') {
            activityType = type.toUpperCase();
            
            if (activityUrl) {
                activityOptions.url = activityUrl; 
            }
        } else if (type === 'streaming') {
            activityType = 'STREAMING';
            
            if (!activityUrl || !activityUrl.startsWith('http')) {
                 return message.reply('❌ For `streaming` status, you must provide a valid streaming URL (e.g., Twitch or YouTube).');
            }
            activityOptions.url = activityUrl;
        } else {
            return message.reply('❌ Invalid status type. Use `playing`, `streaming`, `watching`, `listening`, `competing`, or `reset`.');
        }

        try {
            await client.user.setActivity(activityOptions.name, { 
                type: activityType, 
                url: activityOptions.url 
            });
            
            const urlText = activityOptions.url ? ` (Link: ${activityOptions.url})` : '';
            return message.reply(`✅ Status set to **${activityType}**: \`${activityMessage}\`${urlText}`);

        } catch (error) {
            console.error('Failed to set activity:', error);
            return message.reply('❌ Failed to set status. Check the URL/message or try again later.');
        }
    }
            
    if (message.content.startsWith(`${PREFIX}set`)) {
        const args = message.content.split(' ');
        
        if (args.length >= 2 && args[1].toLowerCase() === 'disable') {
            if (autoMessageInterval) {
                clearInterval(autoMessageInterval);
                autoMessageInterval = null;
                return message.reply('❌ Auto-message **disabled**.');
            } else {
                return message.reply('⚠️ Auto-message is already disabled.');
            }
        }

        if (args.length < 3) return message.reply('Usage: `!set <channel id> <ms>` or `!set disable`');

        const channelId = args[1];
        const ms = parseInt(args[2]);
        if (isNaN(ms)) return message.reply('Invalid milliseconds value.');

        const channel = client.channels.cache.get(channelId);
        if (!channel || !channel.isText()) return message.reply('Invalid channel ID.');

        if (autoMessageInterval) clearInterval(autoMessageInterval);

        autoMessageInterval = setInterval(() => {
            const randomWord = words[Math.floor(Math.random() * words.length)];
            channel.send(randomWord).catch(console.error);
        }, ms);
        
        message.reply(`✅ Auto-message set to run every ${ms}ms in <#${channelId}>.`);
    }

    if (message.content.startsWith(`${PREFIX}auto`)) {
        const args = message.content.split(' ');
        
        if (args.length >= 2 && args[1].toLowerCase() === 'disable') {
            autoReactEnabled = false;
            autoReactBotIds = [];
            return message.reply('❌ Auto-reaction disabled.');
        }
        
        if (args.length < 2) {
            autoReactEnabled = true; 
            autoReactBotIds = [];
            return message.reply('✅ Auto-reaction enabled for all messages.');
        }
        autoReactEnabled = true; 
        autoReactBotIds = args.slice(1);
        return message.reply(`✅ Auto-reaction enabled for bots: ${autoReactBotIds.join(', ')}.`);
    }

    if (message.content.startsWith(`${PREFIX}mention`)) {
        const args = message.content.split(' ');
        
        if (args.length >= 2 && args[1].toLowerCase() === 'disable') {
            mentionAutoReplyEnabled = false; 
            return message.reply('❌ Mention auto-reply disabled.');
        }
        const replyMessage = args.slice(1).join(' ');
        
        if (!replyMessage) {
            return message.reply('Usage: `!mention <message>` or `!mention disable`');
        }
        mentionAutoReplyMessage = replyMessage;
        mentionAutoReplyEnabled = true; 
        return message.reply(`✅ Mention auto-reply set to: **${replyMessage}**`);
    }

    if (message.content.startsWith(`${PREFIX}join`)) {
        const args = message.content.split(' ');
        if (args.length < 2) return message.reply('Usage: `!join <voice channel id>`');
        const channelId = args[1];
        const voiceChannel = client.channels.cache.get(channelId);
        if (!voiceChannel || voiceChannel.type !== 2) return message.reply('Invalid voice channel ID.');
        if (currentConnection) {
            currentConnection.destroy();
            currentConnection = null;
        }
        try {
            const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: voiceChannel.guild.id,
                adapterCreator: voiceChannel.guild.voiceAdapterCreator,
                selfDeaf: true,
            });
            currentConnection = connection;
            connection.on(VoiceConnectionStatus.Disconnected, async (oldState, newState) => {
                try {
                    await Promise.race([
                        entersState(connection, VoiceConnectionStatus.Signalling, 5_000),
                        entersState(connection, VoiceConnectionStatus.Connecting, 5_000),
                    ]);
                } catch (error) {
                    connection.destroy();
                    currentConnection = null;
                    console.error('Voice connection lost and could not reconnect:', error);
                }
            });
            await message.reply(`✅ Joined voice channel: ${voiceChannel.name}`);
        } catch (error) {
            console.error(error);
            message.reply('❌ Failed to join voice channel.');
        }
    }

    if (message.content.startsWith(`${PREFIX}clone`)) {
        const args = message.content.split(' ');
        if (args.length < 3) return message.reply('Usage: `!clone <target server id> <my server id>`');
    
        const targetGuildId = args[1];
        const sourceGuildId = args[2];
    
        const targetGuild = client.guilds.cache.get(targetGuildId);
        const sourceGuild = client.guilds.cache.get(sourceGuildId);
    
        if (!targetGuild || !sourceGuild) return message.reply('Invalid source or target guild ID.');
    
        await message.reply('Starting server clone...');
    
        try {
            for (const role of sourceGuild.roles.cache.sort((a, b) => b.position - a.position).values()) {
                if (role.managed || role.name === '@everyone') continue;
                await targetGuild.roles.create({
                    name: role.name,
                    color: role.color,
                    permissions: role.permissions,
                    hoist: role.hoist,
                    mentionable: role.mentionable
                });
            }
    
            const channelMapping = new Map();
    
            for (const category of sourceGuild.channels.cache.filter(c => c.type === 4).sort((a, b) => a.position - b.position).values()) {
                const newCategory = await targetGuild.channels.create({ name: category.name, type: 4 });
                channelMapping.set(category.id, newCategory.id);
    
                for (const channel of sourceGuild.channels.cache.filter(c => c.parentId === category.id).sort((a, b) => a.position - b.position).values()) {
                    const newChannel = await targetGuild.channels.create({
                        name: channel.name,
                        type: channel.type,
                        parent: newCategory.id,
                        topic: channel.topic,
                        rateLimitPerUser: channel.rateLimitPerUser,
                        nsfw: channel.nsfw
                    });
                    channelMapping.set(channel.id, newChannel.id);
                }
            }
    
            for (const channel of sourceGuild.channels.cache.filter(c => c.parentId === null && c.type !== 4).sort((a, b) => a.position - b.position).values()) {
                const newChannel = await targetGuild.channels.create({
                    name: channel.name,
                    type: channel.type,
                    topic: channel.topic,
                    rateLimitPerUser: channel.rateLimitPerUser,
                    nsfw: channel.nsfw
                });
                channelMapping.set(channel.id, newChannel.id);
            }
    
            message.reply('✅ Server cloning finished successfully (Roles and Channels).');
        } catch (error) {
            console.error(error);
            message.reply('❌ An error occurred during cloning.');
        }
    }

    if (message.content.startsWith(`${PREFIX}tax`)) {
        const args = message.content.split(' ');
        if (args.length < 2) return message.reply('Usage: `!tax <amount (k/m)>`');
    
        let amount = args[1].toLowerCase();
        let numAmount = 0;
    
        if (amount.endsWith('k')) {
            numAmount = parseFloat(amount.slice(0, -1)) * 1000;
        } else if (amount.endsWith('m')) {
            numAmount = parseFloat(amount.slice(0, -1)) * 1000000;
        } else {
            numAmount = parseInt(amount);
        }
    
        if (isNaN(numAmount) || numAmount <= 0) return message.reply('Invalid amount.');
    
        const total = Math.floor(numAmount * (20 / 19) + 1);
        const taxAmount = total - numAmount;
    
        message.reply(` To receive **${numAmount.toLocaleString()}**, the sender must pay **${total.toLocaleString()}** (Tax: ${taxAmount.toLocaleString()}).`);
    }

    if (message.content.startsWith(`${PREFIX}shop`)) {
        const args = message.content.split(' ').slice(1);
        
        if (args.length >= 1 && args[0].toLowerCase() === 'disable') {
            if (shopInterval) {
                clearInterval(shopInterval);
                shopInterval = null;
                return message.reply('❌ Shop message auto-repeat **disabled**.');
            } else {
                return message.reply('⚠️ Shop message auto-repeat is already disabled.');
            }
        }
        
        if (args.length === 0) return message.reply('Usage: `!shop <channelid1> <channelid2> ...` or `!shop disable`');
        
        const shopMessage = fs.readFileSync('shop.txt', 'utf-8').trim();
        for (const channelId of args) {
            const channel = client.channels.cache.get(channelId);
            if (channel && channel.isText()) {                   
                   channel.send(shopMessage).catch(console.error);
                }
            }
        
        if (shopInterval) clearInterval(shopInterval);
        
        shopInterval = setInterval(() => {
            for (const channelId of args) {
                const channel = client.channels.cache.get(channelId);
                if (channel && channel.isText()) {                   
                   channel.send(shopMessage).catch(console.error);
                }
            }
        }, 4500000); 
        
        message.reply(`✅ Shop message sent and will repeat every 1 hour and 15 minutes.`);
    }

    if (message.content.startsWith(`${PREFIX}dm`)) {
        const args = message.content.split(' ').slice(1);
        
        if (args.length === 0) return message.reply('Usage: `!dm <رسالة الرد> | !dm disable`');
        const action = args[0].toLowerCase();

        if (action === 'disable') {
            dmAutoReplyEnabled = false;
            return message.reply('❌ DM auto-reply **disabled**.');
        } 
        
        const replyMessage = args.join(' ');
        if (!replyMessage.trim()) return message.reply('❌ The reply message cannot be empty.');

        mentionAutoReplyMessage = replyMessage; 
        dmAutoReplyEnabled = true;
        return message.reply(`✅ DM auto-reply **enabled**. Reply message set to: **${replyMessage}**`);
    }
});

client.on('messageReactionAdd', async (reaction, user) => {

    if (!selfModeEnabled) return; 
    if (!autoReactEnabled) return; 
    if (user.id === client.user.id) return; 
    
    if (reaction.message.partial) await reaction.message.fetch();

    if (autoReactBotIds.length === 0 || autoReactBotIds.includes(reaction.message.author.id)) {
        await reaction.message.react(reaction.emoji).catch(console.error);
    }
});

client.on('messageCreate', async message => {
    
    if (!selfModeEnabled) return; 
    if (message.author.id === client.user.id) return;
    
    if (mentionAutoReplyEnabled && mentionAutoReplyMessage && message.mentions.users.has(client.user.id)) {
        try {
            await message.reply(mentionAutoReplyMessage);
            return;
        } catch (err) {
            console.error('Failed to send mention auto-reply:', err);
        }
    }
    
    if (dmAutoReplyEnabled && mentionAutoReplyMessage && (message.channel.type === 'DM' || message.channel.type === 1)) {
        try {
            await message.channel.send(mentionAutoReplyMessage);
        } catch (err) {
            console.error('Failed to send DM reply:', err);
        }
    }
});

client.on('error', error => {
    console.error('Client error:', error);
});

client.login('YOUR_TOKEN_HERE'); 
